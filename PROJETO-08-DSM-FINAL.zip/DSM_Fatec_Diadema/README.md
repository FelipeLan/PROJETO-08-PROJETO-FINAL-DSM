# DSM | FATEC Diadema

Aplicativo Android desenvolvido em Java para apresentar o curso superior de **Desenvolvimento de Software Multiplataforma (DSM)** da FATEC Diadema – Luigi Papaiz.

## Funcionalidades

- **Sobre o Curso:** apresenta os conteúdos estudados, perfil profissional, áreas de atuação e dados da oferta do curso em Diadema.
- **Vestibular:** explica as etapas do processo seletivo, apresenta o calendário do 1º semestre de 2027, dicas e acesso aos sites oficiais.
- **Vídeo Institucional:** reproduz o vídeo fornecido usando `VideoView`, com capa de pré-visualização e controles para reproduzir, pausar e parar. O MP4 foi convertido para H.264 Baseline + AAC-LC para ampliar a compatibilidade com dispositivos Android.
- **Navegação:** as telas são conectadas com `Intent` explícitos.

## Tecnologias utilizadas

- Java
- Android Studio
- AndroidX AppCompat
- XML para as interfaces
- `Intent` para navegação entre Activities
- `VideoView` para reprodução de mídia local

## Como executar

1. Descompacte o projeto.
2. Abra a pasta `DSM_Fatec_Diadema` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute o aplicativo em um emulador ou dispositivo Android.

## Arquivo de vídeo

O vídeo institucional está armazenado em:

`app/src/main/res/raw/dsm_institucional.mp4`

A imagem de pré-visualização está em `app/src/main/res/drawable-nodpi/video_poster.jpg`. Toque na capa ou no botão REPRODUZIR para iniciar o vídeo.

O arquivo é carregado diretamente dos recursos do aplicativo, portanto a reprodução não depende de uma URL externa.

## Estrutura principal

```text
app/src/main/java/br/gov/sp/cps/seekbarvideo/
├── MainActivity.java
├── VestibularActivity.java
└── VideoActivity.java

app/src/main/res/layout/
├── activity_main.xml
├── activity_vestibular.xml
└── activity_video.xml

app/src/main/res/raw/
└── dsm_institucional.mp4

app/src/main/res/drawable-nodpi/
└── video_poster.jpg
```

## Fontes institucionais consultadas

- FATEC Diadema – DSM: https://fatecdiadema.cps.sp.gov.br/cursos-fatec-diadema/tecnologia-em-desenvolvimento-de-software-multiplataforma/
- Portal do Vestibular Fatec: https://vestibular.fatec.sp.gov.br/
- Centro Paula Souza – calendário do Vestibular: https://www.cps.sp.gov.br/centro-paula-souza-prorroga-inscricoes-para-o-vestibular-das-fatecs-ate-16-de-novembro/

> Observação: as datas do vestibular são referentes ao processo seletivo para o 1º semestre de 2027. Consulte sempre o portal oficial para confirmar atualizações.


## Ajustes de compatibilidade (versão 1.1)

- Cores do texto e do fundo dos botões definidas explicitamente, com remoção da tonalização automática do tema.
- Capa visível enquanto o player carrega e opção de tocar na capa para reproduzir.
- Vídeo convertido para H.264 Baseline (yuv420p) e áudio AAC-LC.
