package br.gov.sp.cps.seekbarvideo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnVestibular = findViewById(R.id.btnVestibular);
        Button btnVideo = findViewById(R.id.btnVideo);

        btnVestibular.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, VestibularActivity.class)));

        btnVideo.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, VideoActivity.class)));
    }
}
