package br.gov.sp.cps.seekbarvideo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class VestibularActivity extends AppCompatActivity {

    private static final String URL_VESTIBULAR = "https://vestibular.fatec.sp.gov.br/";
    private static final String URL_FATEC_DIADEMA = "https://fatecdiadema.cps.sp.gov.br/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vestibular);

        Button btnSiteVestibular = findViewById(R.id.btnSiteVestibular);
        Button btnSiteFatec = findViewById(R.id.btnSiteFatec);
        Button btnVoltar = findViewById(R.id.btnVoltarVestibular);

        btnSiteVestibular.setOnClickListener(v -> abrirSite(URL_VESTIBULAR));
        btnSiteFatec.setOnClickListener(v -> abrirSite(URL_FATEC_DIADEMA));
        btnVoltar.setOnClickListener(v -> voltarParaInicio());
    }

    private void abrirSite(String endereco) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(endereco));
        startActivity(intent);
    }

    private void voltarParaInicio() {
        Intent intent = new Intent(VestibularActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}
