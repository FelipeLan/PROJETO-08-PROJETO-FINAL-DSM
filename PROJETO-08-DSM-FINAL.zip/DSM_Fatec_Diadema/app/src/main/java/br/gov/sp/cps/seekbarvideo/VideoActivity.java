package br.gov.sp.cps.seekbarvideo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class VideoActivity extends AppCompatActivity {

    private VideoView videoView;
    private ImageView imageVideoPoster;
    private Button btnPlay;
    private Button btnPause;
    private Button btnStop;
    private TextView txtStatus;
    private boolean videoPreparado = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        videoView = findViewById(R.id.videoViewInstitucional);
        imageVideoPoster = findViewById(R.id.imageVideoPoster);
        btnPlay = findViewById(R.id.btnPlay);
        btnPause = findViewById(R.id.btnPause);
        btnStop = findViewById(R.id.btnStop);
        txtStatus = findViewById(R.id.txtStatusVideo);
        Button btnVoltar = findViewById(R.id.btnVoltarVideo);

        // Os botões permanecem visíveis enquanto o vídeo carrega.
        btnPlay.setOnClickListener(v -> reproduzir());
        btnPause.setOnClickListener(v -> pausar());
        btnStop.setOnClickListener(v -> parar());
        imageVideoPoster.setOnClickListener(v -> reproduzir());
        btnVoltar.setOnClickListener(v -> voltarParaInicio());

        carregarVideoInstitucional();
    }

    private void carregarVideoInstitucional() {
        txtStatus.setText("Preparando vídeo institucional...");
        imageVideoPoster.setVisibility(View.VISIBLE);

        Uri videoUri = Uri.parse(
                "android.resource://" + getPackageName() + "/" + R.raw.dsm_institucional
        );

        videoView.setOnPreparedListener(mediaPlayer -> {
            videoPreparado = true;
            txtStatus.setText("Vídeo pronto. Toque em REPRODUZIR para assistir.");
        });

        videoView.setOnCompletionListener(mediaPlayer -> {
            txtStatus.setText("Reprodução concluída. Toque em REPRODUZIR para assistir novamente.");
            videoView.seekTo(0);
            imageVideoPoster.setVisibility(View.VISIBLE);
        });

        videoView.setOnErrorListener((mediaPlayer, what, extra) -> {
            videoPreparado = false;
            imageVideoPoster.setVisibility(View.VISIBLE);
            txtStatus.setText("Falha ao reproduzir o vídeo (código " + what + "/" + extra + ").");
            return true;
        });

        videoView.setVideoURI(videoUri);
        videoView.requestFocus();
    }

    private void reproduzir() {
        if (!videoPreparado) {
            txtStatus.setText("O vídeo ainda está carregando. Aguarde um instante.");
            return;
        }
        imageVideoPoster.setVisibility(View.GONE);
        videoView.start();
        txtStatus.setText("Reproduzindo vídeo institucional...");
    }

    private void pausar() {
        if (!videoPreparado) {
            txtStatus.setText("Aguarde o carregamento do vídeo para pausar.");
            return;
        }
        if (videoView.isPlaying()) {
            videoView.pause();
            txtStatus.setText("Vídeo pausado.");
        }
    }

    private void parar() {
        if (!videoPreparado) {
            txtStatus.setText("Aguarde o carregamento do vídeo para parar.");
            return;
        }
        videoView.pause();
        videoView.seekTo(0);
        imageVideoPoster.setVisibility(View.VISIBLE);
        txtStatus.setText("Vídeo parado. Toque em REPRODUZIR para começar novamente.");
    }

    private void voltarParaInicio() {
        if (videoView != null && videoView.isPlaying()) {
            videoView.pause();
        }
        Intent intent = new Intent(VideoActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onPause() {
        if (videoView != null && videoView.isPlaying()) {
            videoView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (videoView != null) {
            videoView.stopPlayback();
        }
        super.onDestroy();
    }
}
